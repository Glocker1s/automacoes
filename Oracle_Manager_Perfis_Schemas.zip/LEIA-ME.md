# Oracle Manager — profiles gerados

## Conteúdo

- Schemas recebidos: **204** (sem repetição).
- Profiles novos gerados: **198**.
- Profiles que já existem e **não foram sobrescritos**: AGR_CADASTRO, AGR_DBA, AGR_SALDO, CORRWIN, COTACOES, SINAWIN.
- Profiles novos com masking habilitado: AGR_EXTRANET, AGR_PRODUTO, FRN_TEMA_MYCAPITAL, HOMEBROKER, REL.
- Profiles novos sem SQL de masking correspondente: `masking.enabled: false` e `masking.scripts: []`.

## Como instalar

1. Faça backup do repositório atual e extraia a pasta `Oracle_Manager/config/oracle_manager/databases/` na raiz do repositório, **sem remover os arquivos atuais**.
2. Não sobrescreva os seis profiles existentes: eles foram intencionalmente excluídos do pacote.
3. Execute o Project Sync no AAP e confira o carregamento das configurações antes de qualquer operação com dados.
4. Confira a existência dos arquivos `roles/oracle_manager/files/masking/*.sql` indicados nos profiles com masking habilitado.
5. Se necessário, adapte SIDs, PDBs, hosts, política de senha, grants, armazenamento e políticas de cada ambiente.

## Atenções antes de colocar em uso

- Os hosts/SIDs, `drop_users: true`, `allow_completed_with_errors: true` e `allow_partial_table_loads_with_warning: true` foram herdados **literalmente** de `agr_cadastro.yml`, conforme solicitado. Não foram verificados nos bancos de destino. Em particular, um restore completo pode executar `DROP USER ... CASCADE`, e o tratamento de carga parcial pode aceitar dados não importados integralmente.
- Profiles sem masking ficam com masking desabilitado. **Isso não comprova que os dados estejam anonimizados**; não utilize dados sensíveis de PRD em não produção sem a política do banco/cliente.
- **Revisão obrigatória** de schemas potencialmente administrativos ou vinculados ao próprio Oracle antes de usá-los em restore/sync: OUTLN, PERFSTAT, XDB, MGMT_VIEW, DBA_AUTOMACAO, AGR_DBA. Em especial, `XDB`, `OUTLN` e `PERFSTAT` não devem ser tratados como schemas comuns sem validação do DBA.
- O mapeamento dos oito arquivos SQL de masking é **exato pelo nome**, não por prefixo. Ex.: `AGR_PRODUTO` possui SQL próprio; `USR_AGR_PRODUTO` não herda automaticamente esse mesmo SQL.
- Se vários profiles usarem os mesmos hosts, **não execute jobs concorrentes** na versão atual do Oracle Manager: há recursos de storage/Oracle DIRECTORY compartilhados.
- Este pacote cria **configurações**, não cria schemas, valida existência nos bancos, nem executa backups ou restores.

## Maskings existentes (scripts identificados no projeto)

- `AGR_CADASTRO` → `masking/agr_cadastro_masking.sql` — profile existente, não substituído
- `AGR_EXTRANET` → `masking/agr_extranet_masking.sql` — novo profile gerado
- `AGR_PRODUTO` → `masking/agr_produto_masking.sql` — novo profile gerado
- `CORRWIN` → `masking/corrwin_masking.sql` — profile existente, não substituído
- `FRN_TEMA_MYCAPITAL` → `masking/frn_tema_mycapital_masking.sql` — novo profile gerado
- `HOMEBROKER` → `masking/homebroker_masking.sql` — novo profile gerado
- `REL` → `masking/rel_masking.sql` — novo profile gerado
- `SINAWIN` → `masking/sinawin_masking.sql` — profile existente, não substituído

Consulte `INVENTARIO_PERFIS.csv` para a relação completa e status de cada profile.
